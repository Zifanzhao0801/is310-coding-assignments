** This is the instruction of the Maze for IS 310 Assignment created by Zifan Zhao
*These are the tools that can be used to solve the maze

- `cd <directory_name>` 
- `cat <file_name>` 